package com.bharath.training.model;

import java.io.Serializable;

public class BharathDepartment implements Serializable {
    private int departmentId;
    private String departmentName;

    public BharathDepartment() {
    }

	public BharathDepartment(int departmentId, String departmentName) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "BharathDepartment [departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}

    
}
