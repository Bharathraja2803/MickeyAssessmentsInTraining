package com.bharath.training.model;

import java.io.Serializable;

public class BharathEmpDepartmentMapping implements Serializable {
    private int departmentId;
    private int employeeId;

    public BharathEmpDepartmentMapping() {
    }

    public BharathEmpDepartmentMapping(int departmentId, int employeeId) {
        this.departmentId = departmentId;
        this.employeeId = employeeId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    @Override
    public String toString() {
        return "BharathEmpDepartmentMapping{" +
                "departmentId=" + departmentId +
                ", employeeId=" + employeeId +
                '}';
    }
}
