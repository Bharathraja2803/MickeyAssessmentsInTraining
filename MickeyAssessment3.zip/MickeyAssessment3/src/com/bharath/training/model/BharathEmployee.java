package com.bharath.training.model;

import java.io.Serializable;

public class BharathEmployee implements Serializable {
    private int employeeId;
    private String empName;
    private String empEmailId;

    public BharathEmployee() {
    }

    public BharathEmployee(int employeeId, String empName, String empEmailId) {
        this.employeeId = employeeId;
        this.empName = empName;
        this.empEmailId = empEmailId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpEmailId() {
        return empEmailId;
    }

    public void setEmpEmailId(String empEmailId) {
        this.empEmailId = empEmailId;
    }

    @Override
    public String toString() {
        return "BharathEmployee{" +
                "employeeId=" + employeeId +
                ", empName='" + empName + '\'' +
                ", empEmailId='" + empEmailId + '\'' +
                '}';
    }
}
