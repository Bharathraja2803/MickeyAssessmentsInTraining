package com.bharath.training.servlet.adding_data_1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bharath.training.dao.BharathDepartmentDao;
import com.bharath.training.dao.BharathDepartmentDaoImpl;
import com.bharath.training.model.BharathDepartment;

/**
 * This servlet is used to add the data to the department table using Department DAO and Department DAO impl classes
 * @author bharath-22329
 *
 */
public class AddDepartmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String departmentName = request.getParameter("departmentName");
		
		BharathDepartment bharathDepartment = new BharathDepartment();
		bharathDepartment.setDepartmentName(departmentName);
		BharathDepartmentDao bharathDepartmentDao = new BharathDepartmentDaoImpl();
		
		HttpSession session = request.getSession();
		if(!bharathDepartmentDao.addDepartment(bharathDepartment)){
			session.setAttribute("somethingWentWrong", "y");
			response.sendRedirect("addDepartment.jsp");
			return;
		}
		
		response.sendRedirect("viewAllDepartment.jsp");
	}

}
