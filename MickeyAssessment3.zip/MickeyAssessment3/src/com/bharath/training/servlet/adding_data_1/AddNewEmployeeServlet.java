package com.bharath.training.servlet.adding_data_1;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bharath.training.dao.BharathDepartmentDao;
import com.bharath.training.dao.BharathDepartmentDaoImpl;
import com.bharath.training.dao.BharathEmpDepartmentMappingDao;
import com.bharath.training.dao.BharathEmpDepartmentMappingDaoImpl;
import com.bharath.training.dao.BharathEmpSalaryDetailsDao;
import com.bharath.training.dao.BharathEmpSalaryDetailsDaoImpl;
import com.bharath.training.dao.BharathEmployeeDao;
import com.bharath.training.dao.BharathEmployeeDaoImpl;
import com.bharath.training.model.BharathDepartment;
import com.bharath.training.model.BharathEmpDepartmentMapping;
import com.bharath.training.model.BharathEmpSalaryDetails;
import com.bharath.training.model.BharathEmployee;

import java.io.IOException;

/**
 * This Servlet is used to add the data to Employee, department mapping and salary mapping table using DAO and DAO implementation
 * @author bharath-22329
 *
 */
public class AddNewEmployeeServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String employeeName = request.getParameter("employeeName");
		String employeeEmailId = request.getParameter("employeeEmailId");
		HttpSession session = request.getSession();
		
		int departmentId = -1;
		
		try{
			departmentId = Integer.parseInt(request.getParameter("departmentId"));
		}catch(NumberFormatException e){
			session.setAttribute("isDepartmentIsInvalid", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		int salary = -1;
		try{
			salary = Integer.parseInt(request.getParameter("salary"));
		}catch(NumberFormatException e){
			session.setAttribute("isSalaryInvalid", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		BharathDepartmentDao bharathDepartmentDaoImpl = new BharathDepartmentDaoImpl();
		BharathDepartment bharathDepartment = bharathDepartmentDaoImpl.getDepartmentByDepartmentId(departmentId);
		
		
		if(bharathDepartment == null){
			session.setAttribute("isDepartmentIsInvalid", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		BharathEmployeeDao bharathEmployeeDaoImpl = new BharathEmployeeDaoImpl();
		
		int employeeIdIfEmailAlreadyExits = bharathEmployeeDaoImpl.getEmployeeIdByMailId(employeeEmailId);
		
		if(employeeIdIfEmailAlreadyExits != -1){
			session.setAttribute("emailAlreadyExits", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		BharathEmployee bharathEmployee = new BharathEmployee();
		bharathEmployee.setEmpName(employeeName);
		bharathEmployee.setEmpEmailId(employeeEmailId);
		int employeeId = bharathEmployeeDaoImpl.addEmployee(bharathEmployee);
		if(employeeId == -1){
			session.setAttribute("somethingWentWrong", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		BharathEmpDepartmentMapping bharathEmpDepartmentMapping = new BharathEmpDepartmentMapping(departmentId, employeeId);
		BharathEmpDepartmentMappingDao bharathEmpDepartmentMappingDaoImpl = new BharathEmpDepartmentMappingDaoImpl();
		boolean isEmployeeDepartmentMappingSuccessful = bharathEmpDepartmentMappingDaoImpl.addEmployeeDepartmentMapping(bharathEmpDepartmentMapping);
		
		if(!isEmployeeDepartmentMappingSuccessful){
			session.setAttribute("somethingWentWrong", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		BharathEmpSalaryDetails bharathEmpSalaryDetails = new BharathEmpSalaryDetails(employeeId, salary);
		BharathEmpSalaryDetailsDao bharathEmpSalaryDetailsDaoImpl = new BharathEmpSalaryDetailsDaoImpl();
		
		boolean isEmployeeSalaryMappingAddedSuccessfully = bharathEmpSalaryDetailsDaoImpl.addSalaryDetails(bharathEmpSalaryDetails);
		
		if(!isEmployeeSalaryMappingAddedSuccessfully){
			session.setAttribute("somethingWentWrong", "y");
			response.sendRedirect("addEmployee.jsp");
			return;
		}
		
		session.setAttribute("employeeAddedSuccessfully", "y");
		response.sendRedirect("viewAllEmployee.jsp");
    }
}
