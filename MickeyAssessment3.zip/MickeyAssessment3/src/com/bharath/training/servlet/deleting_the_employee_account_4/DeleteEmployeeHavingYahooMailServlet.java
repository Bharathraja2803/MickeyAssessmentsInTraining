package com.bharath.training.servlet.deleting_the_employee_account_4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

/**
 * This servlet is used to delete the employee details from employee, department mapping and salary mapping table
 * @author bharath-22329
 *
 */
public class DeleteEmployeeHavingYahooMailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Criteria criteria = new Criteria(new Column("BHARATH_EMPLOYEE", "EMP_EMAIL_ID"), "@yahoo.com", QueryConstants.ENDS_WITH);
		try {
			DataObject employeesHavingYahooMailid = DataAccess.get("BHARATH_EMPLOYEE", criteria);
			List<Integer> listOfEmployeeIdToBeDeleted = new ArrayList<>();			
			Iterator<Row> it = employeesHavingYahooMailid.getRows("BHARATH_EMPLOYEE");
			while(it.hasNext()){
				Row row = it.next();
				listOfEmployeeIdToBeDeleted.add((int)row.get("EMPLOYEE_ID"));
			}
			if(listOfEmployeeIdToBeDeleted.isEmpty()){
				session.setAttribute("somethingWentWrong", "y");
				response.sendRedirect("viewAllEmployee.jsp");
				return;
			}
			
			DataObject dataObjectOfDepartmentMappingTable = DataAccess.get("BHARATH_EMP_DEPARTMENT_MAPPING", (Criteria) null);
			
			
			
			
			
			DataObject dataObjectOfSalaryMappingTable = DataAccess.get("BHARATH_EMP_SALARYDETAILS", (Criteria) null);
			
			for(int employeeId : listOfEmployeeIdToBeDeleted){
				Criteria gettingEmployeeMatchingEmployeeId = new Criteria(new Column("BHARATH_EMP_DEPARTMENT_MAPPING", "EMPLOYEE_ID"), new Integer(employeeId), QueryConstants.EQUAL);
				dataObjectOfDepartmentMappingTable.deleteRows("BHARATH_EMP_DEPARTMENT_MAPPING", gettingEmployeeMatchingEmployeeId);
				
				Criteria gettingEmployeeMatchingEmployeeIdSalaryCriteria = new Criteria(new Column("BHARATH_EMP_SALARYDETAILS", "EMPLOYEE_ID"), new Integer(employeeId), QueryConstants.EQUAL);
				dataObjectOfSalaryMappingTable.deleteRows("BHARATH_EMP_SALARYDETAILS", gettingEmployeeMatchingEmployeeIdSalaryCriteria);
			}
			
			DataAccess.update(dataObjectOfDepartmentMappingTable);
			DataAccess.update(dataObjectOfSalaryMappingTable);
			
			DataObject dataObjectOfEmployeeTable = DataAccess.get("BHARATH_EMPLOYEE", (Criteria) null);
			dataObjectOfEmployeeTable.deleteRows("BHARATH_EMPLOYEE", criteria);
			DataAccess.update(dataObjectOfEmployeeTable);
			session.setAttribute("deletingTheYahooUserMailIdSuccessful", "y");
			response.sendRedirect("viewAllEmployee.jsp");
		} catch (DataAccessException e) {
			session.setAttribute("somethingWentWrong", "y");
			response.sendRedirect("viewAllEmployee.jsp");
		}
		
	}

}
