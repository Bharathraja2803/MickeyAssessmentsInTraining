package com.bharath.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.bharath.training.model.BharathEmployee;

public class BharathEmployeeDaoImpl implements BharathEmployeeDao{

	/**
	 * This method is used to insert the employee record and return the employee id
	 */
	@Override
	public int addEmployee(BharathEmployee bharathEmployee) {
		Row row = new Row("BHARATH_EMPLOYEE");
		row.set("EMP_NAME", bharathEmployee.getEmpName());
		row.set("EMP_EMAIL_ID", bharathEmployee.getEmpEmailId());
		DataObject dataObject = new WritableDataObject();
		try {
			dataObject.addRow(row);
			DataAccess.add(dataObject);
			return getEmployeeIdByMailId(bharathEmployee.getEmpEmailId());
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return -1;
		}
	}


	/**
	 * This method is used to get the employee id by using email id (assuming email id is unique for each employee)
	 */
	public int getEmployeeIdByMailId(String mailId){
		Criteria criteria = new Criteria(new Column("BHARATH_EMPLOYEE", "EMP_EMAIL_ID"), mailId, QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_EMPLOYEE", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_EMPLOYEE");
			if(it.hasNext()){
				Row row = it.next();
				return (int)row.get(1);
			}
			return -1;
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}

	/**
	 * This method is used to list all Employee Details
	 */
	@Override
	public List<BharathEmployee> listAllEmployeeDetails() {
		try {
			DataObject dataObject = DataAccess.get("BHARATH_EMPLOYEE",(Criteria) null);
			Iterator<Row> it = dataObject.getRows("BHARATH_EMPLOYEE");
			List<BharathEmployee> listOfEmployees = new ArrayList<>();
			while(it.hasNext()){
				Row row = it.next();
				BharathEmployee bharathEmployee = new BharathEmployee((int)row.get(1), (String) row.get(2), (String) row.get(3));
				listOfEmployees.add(bharathEmployee);
			}
			
			if(listOfEmployees.isEmpty()){
				System.out.println("There is no record on employees");
				return null;
			}else{
				return listOfEmployees;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}
	
	
}
