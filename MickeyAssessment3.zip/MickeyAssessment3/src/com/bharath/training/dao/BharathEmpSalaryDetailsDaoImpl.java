package com.bharath.training.dao;

import java.util.Iterator;
import java.util.List;

import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.bharath.training.model.BharathEmpSalaryDetails;

public class BharathEmpSalaryDetailsDaoImpl implements BharathEmpSalaryDetailsDao{

	/**
	 * This method inserts the record to the employee salary mapping table
	 */
	@Override
	public boolean addSalaryDetails(BharathEmpSalaryDetails bharathEmpSalaryDetails) {
		Row row = new Row("BHARATH_EMP_SALARYDETAILS");
		row.set("EMPLOYEE_ID", bharathEmpSalaryDetails.getEmployeeId());
		row.set("SALARY", bharathEmpSalaryDetails.getSalary());
		DataObject dataObject = new WritableDataObject();
		try {
			dataObject.addRow(row);
			DataAccess.add(dataObject);
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return false;
		}
		return true;
	}


	/**
	 * This method is used to get the salary details using employeeid
	 */
	@Override
	public BharathEmpSalaryDetails getSalaryDetailsByEmployeeId(int employeeId) {
		Criteria criteria = new Criteria(new Column("BHARATH_EMP_SALARYDETAILS", "EMPLOYEE_ID"), new Integer(employeeId), QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_EMP_SALARYDETAILS", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_EMP_SALARYDETAILS");
			if(it.hasNext()){
				Row row = it.next();
				BharathEmpSalaryDetails bharathEmpSalaryDetails = new BharathEmpSalaryDetails((int)row.get(1), (int)row.get(2));
				return bharathEmpSalaryDetails;
			}else{
				return null;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
		
		
	}

}
