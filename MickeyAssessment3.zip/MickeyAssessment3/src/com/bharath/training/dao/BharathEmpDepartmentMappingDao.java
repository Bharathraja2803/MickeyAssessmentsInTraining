package com.bharath.training.dao;

import java.util.List;

import com.bharath.training.model.BharathEmpDepartmentMapping;

public interface BharathEmpDepartmentMappingDao {
	boolean addEmployeeDepartmentMapping(BharathEmpDepartmentMapping bharathEmpDepartmentMapping);
	List<BharathEmpDepartmentMapping> getEmployeeDepartmentMappingByEmployeeId(int employeeId);
	List<BharathEmpDepartmentMapping> getEmployeeDepartmentMappingByDepartmentId(int departmentId);
}
