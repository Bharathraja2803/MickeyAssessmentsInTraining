package com.bharath.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.bharath.training.model.BharathDepartment;

public class BharathDepartmentDaoImpl implements BharathDepartmentDao{

	/**
	 * This method is used to insert the data into department table
	 */
	@Override
	public boolean addDepartment(BharathDepartment bharathDepartment) {
		Row row = new Row("BHARATH_DEPARTMENT");
		row.set("DEPARTMENT_NAME", bharathDepartment.getDepartmentName());
		DataObject dataObject = new WritableDataObject();
		try {
			dataObject.addRow(row);
			DataAccess.add(dataObject);
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return false;
		}
		return true;
	}

	/**
	 * This method is used to update the department.
	 */
	@Override
	public boolean updateDepartment(BharathDepartment bharathDepartment) {
		
		Criteria criteria = new Criteria(new Column("BHARATH_DEPARTMENT", "DEPARTMENT_ID"), bharathDepartment.getDepartmentId(), QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_DEPARTMENT", criteria);
			Row row = dataObject.getRow("BHARATH_DEPARTMENT");
			row.set("DEPARTMENT_NAME", bharathDepartment.getDepartmentName());
			dataObject.updateRow(row);
			DataAccess.update(dataObject);
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return false;
		}
		
		return true;
	}

	/**
	 * This method provides the list of all departments
	 */
	@Override
	public List<BharathDepartment> readAllDepartment() {
		try {
			DataObject dataObject = DataAccess.get("BHARATH_DEPARTMENT", (Criteria) null);
			Iterator<Row> it = dataObject.getRows("BHARATH_DEPARTMENT");
			List<BharathDepartment> bharathDepartments = new ArrayList<>();
			while(it.hasNext()){
				Row row = it.next();
				BharathDepartment bharathDepartment = new BharathDepartment((int)row.get(1), (String)row.get(2));
				bharathDepartments.add(bharathDepartment);
			}
			
			if(bharathDepartments.isEmpty()){
				System.out.println("There is no record on employees");
				return null;
			}else{
				return bharathDepartments;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}

	/**
	 * This method provides the department object by searching with department id
	 */
	@Override
	public BharathDepartment getDepartmentByDepartmentId(int departmentId) {
		Criteria criteria = new Criteria(new Column("BHARATH_DEPARTMENT", "DEPARTMENT_ID"), new Integer(departmentId), QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_DEPARTMENT", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_DEPARTMENT");
			if(it.hasNext()){
				Row row = it.next();
				BharathDepartment bharathDepartment = new BharathDepartment((int)row.get(1), (String)row.get(2));
				return bharathDepartment;
			}else{
				return null;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}
	
	/**
	 * This method provides the department object by searching with department name
	 */
	@Override
	public BharathDepartment getDepartmentByDepartmentName(String departmentName) {
		Criteria criteria = new Criteria(new Column("BHARATH_DEPARTMENT", "DEPARTMENT_NAME"), departmentName, QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_DEPARTMENT", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_DEPARTMENT");
			if(it.hasNext()){
				Row row = it.next();
				BharathDepartment bharathDepartment = new BharathDepartment((int)row.get(1), (String)row.get(2));
				return bharathDepartment;
			}else{
				return null;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}

}
