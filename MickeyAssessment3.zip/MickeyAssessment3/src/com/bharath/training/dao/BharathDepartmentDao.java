package com.bharath.training.dao;

import java.util.List;

import com.bharath.training.model.BharathDepartment;

public interface BharathDepartmentDao {
	boolean addDepartment(BharathDepartment bharathDepartment);
	boolean updateDepartment(BharathDepartment bharathDepartment);
	List<BharathDepartment> readAllDepartment();
	BharathDepartment getDepartmentByDepartmentId(int departmentId);
	BharathDepartment getDepartmentByDepartmentName(String departmentName);
}
