package com.bharath.training.dao;

import com.bharath.training.model.BharathEmpSalaryDetails;

import java.util.List;

public interface BharathEmpSalaryDetailsDao {
    boolean addSalaryDetails(BharathEmpSalaryDetails bharathEmpSalaryDetails);
    BharathEmpSalaryDetails getSalaryDetailsByEmployeeId(int employeeId);
}
