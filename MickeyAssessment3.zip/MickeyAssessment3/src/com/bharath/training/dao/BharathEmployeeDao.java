package com.bharath.training.dao;

import java.util.List;

import com.bharath.training.model.BharathEmployee;

public interface BharathEmployeeDao {
	int addEmployee(BharathEmployee bharathEmployee);
	List<BharathEmployee> listAllEmployeeDetails();
	int getEmployeeIdByMailId(String mailId);
}
