package com.bharath.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.bharath.training.model.BharathEmpDepartmentMapping;

public class BharathEmpDepartmentMappingDaoImpl implements BharathEmpDepartmentMappingDao{

	/**
	 * This method is used to add the data to the employee department mapping table
	 */
	@Override
	public boolean addEmployeeDepartmentMapping(BharathEmpDepartmentMapping bharathEmpDepartmentMapping) {
		Row row = new Row("BHARATH_EMP_DEPARTMENT_MAPPING");
		row.set("DEPARTMENT_ID", bharathEmpDepartmentMapping.getDepartmentId());
		row.set("EMPLOYEE_ID", bharathEmpDepartmentMapping.getEmployeeId());
		DataObject dataObject = new WritableDataObject();
		try {
			dataObject.addRow(row);
			DataAccess.add(dataObject);
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return false;
		}
		return true;
	}


	/**
	 * This method is used to get the employee department mapping for the employeeid
	 */
	@Override
	public List<BharathEmpDepartmentMapping> getEmployeeDepartmentMappingByEmployeeId(int employeeId) {
		Criteria criteria = new Criteria(new Column("BHARATH_EMP_DEPARTMENT_MAPPING", "EMPLOYEE_ID"), new Integer(employeeId), QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_EMP_DEPARTMENT_MAPPING", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_EMP_DEPARTMENT_MAPPING");
			List<BharathEmpDepartmentMapping> bharathEmpDepartmentMappings = new ArrayList<>();
			while(it.hasNext()){
				Row row = it.next();
				BharathEmpDepartmentMapping bharathEmpDepartmentMapping = new BharathEmpDepartmentMapping((int)row.getInt(1), (int)row.get(2));
				bharathEmpDepartmentMappings.add(bharathEmpDepartmentMapping);
			}
			
			if(bharathEmpDepartmentMappings.isEmpty()){
				System.out.println("There is no record on employees");
				return null;
			}else{
				return bharathEmpDepartmentMappings;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}

	/**
	 * This method is used to get the employee department mappings using department id
	 */
	@Override
	public List<BharathEmpDepartmentMapping> getEmployeeDepartmentMappingByDepartmentId(int departmentId) {
		Criteria criteria = new Criteria(new Column("BHARATH_EMP_DEPARTMENT_MAPPING", "DEPARTMENT_ID"), new Integer(departmentId), QueryConstants.EQUAL);
		try {
			DataObject dataObject = DataAccess.get("BHARATH_EMP_DEPARTMENT_MAPPING", criteria);
			Iterator<Row> it = dataObject.getRows("BHARATH_EMP_DEPARTMENT_MAPPING");
			List<BharathEmpDepartmentMapping> bharathEmpDepartmentMappings = new ArrayList<>();
			while(it.hasNext()){
				Row row = it.next();
				BharathEmpDepartmentMapping bharathEmpDepartmentMapping = new BharathEmpDepartmentMapping((int)row.getInt(1), (int)row.get(2));
				bharathEmpDepartmentMappings.add(bharathEmpDepartmentMapping);
			}
			
			if(bharathEmpDepartmentMappings.isEmpty()){
				System.out.println("There is no record on employees");
				return null;
			}else{
				return bharathEmpDepartmentMappings;
			}
		} catch (DataAccessException e) {
			System.out.println(e.toString());
			return null;
		}
	}
}
